<?
define('BASEPATH', true);
include('../../config.php');
?>
<p>
	<label><?=$lang['ysub_08']?></label> <small style="float:right"><?=$lang['ysub_01']?></small><br/>
	<input class="text-max" type="text" value="" name="url" />
</p>