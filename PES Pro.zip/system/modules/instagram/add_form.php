<?
define('BASEPATH', true);
include('../../config.php');
?>
<p>
	<label><?=$lang['inst_url']?></label> <small style="float:right"><?=$lang['inst_url_desc']?></small><br/>
	<input class="text-max" type="text" value="" name="url" />
</p>