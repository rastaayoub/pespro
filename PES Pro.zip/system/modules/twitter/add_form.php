<?
define('BASEPATH', true);
include('../../config.php');
?>
<p>
	<label><?=$lang['twt_url']?></label> <small style="float:right"><?=$lang['twt_url_desc']?></small><br/>
	<input class="text-max" type="text" value="" name="url" />
</p>