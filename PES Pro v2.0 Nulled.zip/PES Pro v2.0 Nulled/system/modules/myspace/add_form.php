<?
define('BASEPATH', true);
include('../../config.php');
?>
<p>
	<label><?=$lang['myspace_url']?></label> <small style="float:right"><?=$lang['myspace_url_desc']?></small><br/>
	<input class="text-max" type="text" value="" name="url" />
</p>