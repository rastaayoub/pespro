<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['ysub_01'] = 'Youtube Account';
$lang['ysub_02'] = 'Youtube account already exists!';
$lang['ysub_03'] = 'Youtube account added successfully!';
$lang['ysub_04'] = 'Youtube Account dosen\'t exist!';
$lang['ysub_05'] = 'CPC successfully changed!';
$lang['ysub_06'] = 'Change CPC';
$lang['ysub_07'] = 'Received Subscribers';
$lang['ysub_08'] = 'Youtube Username';
$lang['ysub_09'] = 'If you don\'t add your real Youtube username, you can\'t earn coins.';
$lang['ysub_10'] = 'Youtube Subscribers';
$lang['ysub_11'] = 'Press "Subscribe" on the site, then press "Subscribe" on Youtube\'s page. After that close opened window.';
$lang['ysub_12'] = 'Add your Youtube account first!';
$lang['ysub_13'] = 'Subscribe';
$lang['ysub_14'] = 'Subscribe user and after that close window!';
$lang['ysub_15'] = 'skip';
$lang['ysub_16'] = 'SUCCESS! You skipped this user!';
$lang['ysub_17'] = 'Youtube says you aren\'t subscribed to this user!';
$lang['ysub_18'] = 'SUCCESS!';
$lang['ysub_19'] = ' coins were added to your account!';
?>