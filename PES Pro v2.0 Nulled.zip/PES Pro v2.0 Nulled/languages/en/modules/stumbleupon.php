<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['su_01'] = 'URL must be something like: http://www.stumbleupon.com/stumbler/<b>USERNAME</b>';
$lang['su_02'] = 'Profile already added!';
$lang['su_03'] = 'Profile was successfully added!';
$lang['su_04'] = 'skip';
$lang['su_05'] = 'Follow';
$lang['su_06'] = 'Confirm';
$lang['su_07'] = 'SUCCESS! You skipped this user!';
$lang['su_08'] = 'Follow user and close opened window...';
$lang['su_09'] = 'We cannot contact stumbleupon...';
$lang['su_10'] = 'Stumble says you aren\'t following this user!';
$lang['su_11'] = 'SUCCESS!';
$lang['su_12'] = ' coins were added to your account!';

// Add Page
$lang['su_url'] = 'Profile URL';
$lang['su_title'] = 'Name';
$lang['su_url_desc'] = 'Add your profile url here';
$lang['su_title_desc'] = 'Add your profile name here';
?>