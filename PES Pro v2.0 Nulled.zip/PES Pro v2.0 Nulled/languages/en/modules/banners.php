<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['banners_01'] = 'Banners';
$lang['banners_02'] = 'Total Banners';
$lang['banners_03'] = 'Total Impressions';
$lang['banners_04'] = 'Total Clicks';
?>