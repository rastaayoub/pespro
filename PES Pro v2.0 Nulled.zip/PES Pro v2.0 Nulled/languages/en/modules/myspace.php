<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['myspace_01'] = 'MySpace account already added!';
$lang['myspace_02'] = '<b>ERROR:</b> This MySpace account is not valid or doesn\'t exists!';
$lang['myspace_03'] = 'MySpace account was successfully added!';
$lang['myspace_04'] = 'MySpace Username';
$lang['myspace_05'] = 'Connect';
$lang['myspace_06'] = '<b>ERROR:</b> This MySpace account doesn\'t exists!';
$lang['myspace_07'] = 'skip';
$lang['myspace_08'] = 'SUCCESS! You skipped this account!';
$lang['myspace_09'] = 'Become a fan and close opened window...';
$lang['myspace_10'] = 'We cannot contact MySpace...';
$lang['myspace_11'] = 'MySpace says that you are not a fan!';
$lang['myspace_12'] = 'SUCCESS!';
$lang['myspace_13'] = ' coins were added to your account!';
$lang['myspace_14'] = 'MySpace account';
$lang['myspace_15'] = 'Attach your MySpace account here, to be able to earn coins. You have to attach the same account used to connect with other MySpace users.';

// Add Page
$lang['myspace_url'] = 'MySpace Username';
$lang['myspace_url_desc'] = 'Add your MySpace username here';
?>