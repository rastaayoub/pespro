<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['gp_01'] = 'Page was successfully added!';
$lang['gp_02'] = 'SUCCESS! You skipped this page!';
$lang['gp_03'] = 'SUCCESS! You have received <b>-NUM- coins</b>!';
$lang['gp_04'] = 'Page already added!';
$lang['gp_05'] = 'ERROR! You have to be logged in to receive coins!';

// Add Page
$lang['gp_url'] = 'URL';
$lang['gp_title'] = 'Title';
$lang['gp_url_desc'] = 'Add your website url here';
$lang['gp_title_desc'] = 'Add your website title here';
?>